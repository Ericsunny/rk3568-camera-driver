#!/usr/bin/env python3
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

p=argparse.ArgumentParser()
p.add_argument('--dir',required=True)
p.add_argument('--frames',type=int,required=True)
a=p.parse_args()
d=Path(a.dir)
r={}
for mode in ('copy','dmabuf'):
    f=d/(mode+'.h264'); out=d/(mode+'.framemd5')
    q=subprocess.run(['ffmpeg','-v','error','-i',str(f),'-map','0:v:0','-vsync','0','-f','framemd5',str(out)],
                     stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
    (d/(mode+'.ffmpeg.stdout')).write_bytes(q.stdout)
    (d/(mode+'.ffmpeg.stderr')).write_bytes(q.stderr)
    rows=[x for x in out.read_text().splitlines() if x and not x.startswith('#')] if out.exists() else []
    r[mode]={'exit_code':q.returncode,'stderr_bytes':len(q.stderr),'frames':len(rows),
             'stream_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),
             'frame_hashes':[x.rsplit(',',1)[-1].strip() for x in rows]}
r['same_frames']=len(r['copy']['frame_hashes'])==a.frames and r['copy']['frame_hashes']==r['dmabuf']['frame_hashes']
before=(d/'dmesg.before.txt').read_text(errors='replace').splitlines()
after=(d/'dmesg.after.txt').read_text(errors='replace').splitlines()
delta=after[len(before):] if after[:len(before)]==before else []
r['dmesg_prefix']=after[:len(before)]==before
r['error_lines']=[x for x in delta if any(t in x.lower() for t in ('error','fail','oops','warn','timeout','wedg','unknown'))]
r['3a']=(d/'3a.after.txt').read_text().strip()
r['fuser']=(d/'fuser.after.txt').read_text().strip()
(d/'compare.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:v if k not in ('copy','dmabuf') else {x:y for x,y in v.items() if x!='frame_hashes'} for k,v in r.items()},indent=2))
if any(r[x]['exit_code'] != 0 or r[x]['stderr_bytes'] != 0 for x in ('copy','dmabuf')) or not r['same_frames'] or not r['dmesg_prefix'] or r['error_lines'] or r['3a'] != 'active' or r['fuser']:
    raise SystemExit(1)
