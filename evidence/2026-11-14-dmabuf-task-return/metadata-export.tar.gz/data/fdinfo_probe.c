/* Inspect V4L2 MMAP exported buffer without S_FMT, QBUF or STREAMON. */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <linux/videodev2.h>

int main(int argc, char **argv)
{
    int fd=-1, expfd=-1, allocated=0, rc=1;
    struct v4l2_format fmt;
    struct v4l2_requestbuffers req;
    struct v4l2_exportbuffer ex;
    char path[96], line[512]; FILE *f;
    if (argc != 2) return 2;
    fd=open(argv[1],O_RDWR|O_CLOEXEC); if(fd<0){perror("open");goto done;}
    memset(&fmt,0,sizeof(fmt));fmt.type=V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
    if(ioctl(fd,VIDIOC_G_FMT,&fmt)<0){perror("G_FMT");goto done;}
    printf("G_FMT %ux%u planes=%u size=%u\n",fmt.fmt.pix_mp.width,fmt.fmt.pix_mp.height,
           fmt.fmt.pix_mp.num_planes,fmt.fmt.pix_mp.plane_fmt[0].sizeimage);
    memset(&req,0,sizeof(req));req.type=fmt.type;req.memory=V4L2_MEMORY_MMAP;req.count=1;
    if(ioctl(fd,VIDIOC_REQBUFS,&req)<0 || !req.count){perror("REQBUFS");goto done;}
    allocated=1;
    memset(&ex,0,sizeof(ex));ex.type=fmt.type;ex.index=0;ex.plane=0;ex.flags=O_RDWR|O_CLOEXEC;
    if(ioctl(fd,VIDIOC_EXPBUF,&ex)<0){perror("EXPBUF");goto done;}
    expfd=ex.fd;snprintf(path,sizeof(path),"/proc/self/fdinfo/%d",expfd);f=fopen(path,"r");
    if(!f){perror("fdinfo");goto done;}
    while(fgets(line,sizeof(line),f)) fputs(line,stdout);
    if(fclose(f)!=0)goto done;
    rc=0;
done:
    if(expfd>=0)close(expfd);
    if(allocated){memset(&req,0,sizeof(req));req.type=V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
        req.memory=V4L2_MEMORY_MMAP;req.count=0;
        if(ioctl(fd,VIDIOC_REQBUFS,&req)<0){perror("REQBUFS release");rc=1;}}
    if(fd>=0)close(fd);
    printf("FDINFO_PROBE_RC=%d\n",rc);
    return rc;
}
