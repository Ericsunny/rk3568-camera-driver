#!/usr/bin/env python3
import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument('--binary', required=True)
p.add_argument('--device', required=True)
p.add_argument('--out', required=True)
p.add_argument('--width', type=int, required=True)
p.add_argument('--height', type=int, required=True)
p.add_argument('--fps', type=int, required=True)
p.add_argument('--frames', type=int, required=True)
a = p.parse_args()
d = Path(a.out)
d.mkdir(mode=0o700, parents=False, exist_ok=False)
cmd = [a.binary, a.device, str(a.width), str(a.height), str(a.fps), str(a.frames)]
plan = {'purpose': 'live two-encoder same-frame compare; no detect, OSD, event or RTSP',
        'argv': cmd, 'timeout_s': 45, 'stop_sustained_D_s': 3,
        'pass': 'all frames returned from matching task and buffer before QBUF; 0 exit; '
                'full decode and same-frame comparison; no unexplained kernel errors; 3A active',
        'scope': 'diagnostic probe only; no production replacement implied'}
(d/'plan.json').write_text(json.dumps(plan, indent=2)+'\n')
def collect(args):
    return subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
svc = collect(['systemctl','is-active','rkaiq_3A.service'])
busy = collect(['fuser', a.device])
(d/'precheck.json').write_text(json.dumps({'3a_rc':svc.returncode,'3a':svc.stdout.decode(errors='replace').strip(),
                                          'fuser_rc':busy.returncode,'fuser':busy.stdout.decode(errors='replace').strip()},indent=2)+'\n')
if svc.returncode != 0 or busy.returncode != 1: raise SystemExit('precheck failed')
(d/'format.before.txt').write_bytes(collect(['v4l2-ctl','-d',a.device,'--get-fmt-video']).stdout)
(d/'dmesg.before.txt').write_bytes(collect(['dmesg']).stdout)
t0=time.monotonic(); dstart={}; reason=None
with (d/'run.log').open('wb') as log:
    q=subprocess.Popen(cmd,cwd=str(d),stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    while q.poll() is None:
        now=time.monotonic()
        try: tasks=list(Path('/proc/%d/task'%q.pid).iterdir())
        except FileNotFoundError: tasks=[]
        seen=set()
        for t in tasks:
            try: state=(t/'stat').read_text().split(') ',1)[1].split()[0]
            except (FileNotFoundError,IndexError,ProcessLookupError): continue
            if state=='D':
                seen.add(t.name); dstart.setdefault(t.name,now)
                if now-dstart[t.name]>=3: reason='sustained_D_state'
        dstart={k:v for k,v in dstart.items() if k in seen}
        if now-t0>=45: reason='timeout'
        if reason:
            q.send_signal(signal.SIGTERM)
            try: q.wait(timeout=4)
            except subprocess.TimeoutExpired:
                q.kill()
                try: q.wait(timeout=3)
                except subprocess.TimeoutExpired: pass
            break
        time.sleep(.25)
    rc=q.poll()
r={'exit_code':rc,'stop_reason':reason,'elapsed_s':round(time.monotonic()-t0,3),
   'remaining_pid':q.pid if rc is None else None}
(d/'result.json').write_text(json.dumps(r,indent=2)+'\n')
(d/'dmesg.after.txt').write_bytes(collect(['dmesg']).stdout)
(d/'3a.after.txt').write_bytes(collect(['systemctl','is-active','rkaiq_3A.service']).stdout)
(d/'fuser.after.txt').write_bytes(collect(['fuser',a.device]).stdout)
print(json.dumps(r)); print((d/'run.log').read_text(errors='replace'))
if rc != 0 or reason: raise SystemExit(1)
