/* Synthetic, no camera: investigate old board MPP task completion semantics. */
#define main evrec_original_main
#include "evrec.c"
#undef main
#include <rockchip/mpp_task.h>
#include <rockchip/mpp_meta.h>

int main(void)
{
    MppTask task = NULL, submitted = NULL, held[32] = {NULL};
    MppFrame frame = NULL, returned_frame = NULL;
    MppPacket packet = NULL, returned_packet = NULL;
    MppBuffer packet_buffer = NULL;
    MPP_RET r;
    int rc = 1, enqueued = 0, output_ok = 0, nheld = 0, i;
    if (enc_init(640, 480, 640, 1000, 15, 15) != 0) goto done;
    if (!g_mpi->poll || !g_mpi->dequeue || !g_mpi->enqueue) {
        fprintf(stderr, "task API absent\n"); goto done;
    }
    memset(mpp_buffer_get_ptr(g_fbuf), 128, g_fsize);
    if (mpp_buffer_get(g_grp, &packet_buffer, g_fsize) != MPP_OK ||
        mpp_packet_init_with_buffer(&packet, packet_buffer) != MPP_OK ||
        mpp_frame_init(&frame) != MPP_OK) goto done;
    mpp_packet_set_length(packet, 0);
    mpp_frame_set_width(frame, 640); mpp_frame_set_height(frame, 480);
    mpp_frame_set_hor_stride(frame, 640); mpp_frame_set_ver_stride(frame, 480);
    mpp_frame_set_fmt(frame, MPP_FMT_YUV420SP);
    mpp_frame_set_buffer(frame, g_fbuf); mpp_frame_set_pts(frame, 123456);
    r = g_mpi->poll(g_ctx, MPP_PORT_INPUT, (MppPollType)2000);
    printf("input_poll=%d\n", r); fflush(stdout); if (r != MPP_OK) goto done;
    r = g_mpi->dequeue(g_ctx, MPP_PORT_INPUT, &task);
    printf("input_dequeue=%d task=%p\n", r, (void*)task); fflush(stdout);
    if (r != MPP_OK || !task) goto done;
    if (mpp_task_meta_set_frame(task, KEY_INPUT_FRAME, frame) != MPP_OK ||
        mpp_task_meta_set_packet(task, KEY_OUTPUT_PACKET, packet) != MPP_OK) goto done;
    submitted = task;
    r = g_mpi->enqueue(g_ctx, MPP_PORT_INPUT, task); task = NULL;
    printf("input_enqueue=%d\n", r); fflush(stdout); if (r != MPP_OK) goto done;
    enqueued = 1;
    r = g_mpi->poll(g_ctx, MPP_PORT_OUTPUT, (MppPollType)2000);
    printf("output_poll=%d\n", r); fflush(stdout); if (r != MPP_OK) goto done;
    r = g_mpi->dequeue(g_ctx, MPP_PORT_OUTPUT, &task);
    printf("output_dequeue=%d task=%p\n", r, (void*)task); fflush(stdout);
    if (r != MPP_OK || !task) goto done;
    {
        MPP_RET rf = mpp_task_meta_get_frame(task, KEY_INPUT_FRAME, &returned_frame);
        MPP_RET rp = mpp_task_meta_get_packet(task, KEY_OUTPUT_PACKET, &returned_packet);
        printf("returned_frame_rc=%d ptr=%p same=%d returned_packet_rc=%d ptr=%p same=%d len=%zu\n",
               rf, (void*)returned_frame, returned_frame == frame, rp, (void*)returned_packet,
               returned_packet == packet, returned_packet ? mpp_packet_get_length(returned_packet) : 0);
        fflush(stdout);
        if (rp == MPP_OK && returned_packet && mpp_packet_get_length(returned_packet) > 0) output_ok = 1;
    }
    r = g_mpi->enqueue(g_ctx, MPP_PORT_OUTPUT, task); task = NULL;
    printf("output_enqueue=%d\n", r); fflush(stdout);
    if (r != MPP_OK || !output_ok) goto done;
    /* Other empty input tasks may be ready before the submitted task comes
     * back. Hold every dequeued task so the same empty task cannot recur. */
    for (i = 0; i < 32; i++) {
        MppFrame input_return = NULL;
        MPP_RET rf;
        r = g_mpi->poll(g_ctx, MPP_PORT_INPUT, (MppPollType)2000);
        printf("returned_input_poll[%d]=%d\n", i, r); fflush(stdout);
        if (r != MPP_OK) break;
        r = g_mpi->dequeue(g_ctx, MPP_PORT_INPUT, &task);
        if (r != MPP_OK || !task) break;
        held[nheld++] = task;
        rf = mpp_task_meta_get_frame(task, KEY_INPUT_FRAME, &input_return);
        printf("input_return[%d] task=%p same_task=%d frame_rc=%d frame=%p same_frame=%d",
               i, (void*)task, task == submitted, rf, (void*)input_return, input_return == frame);
        if (rf == MPP_OK && input_return && mpp_frame_get_buffer(input_return))
            printf(" pts=%lld fd=%d", (long long)mpp_frame_get_pts(input_return),
                   mpp_buffer_get_fd(mpp_frame_get_buffer(input_return)));
        printf("\n"); fflush(stdout);
        if (task == submitted && rf == MPP_OK && input_return == frame) { rc = 0; break; }
        task = NULL;
    }
    (void)held; (void)nheld;
done:
    /* Complete context before disposing app-owned input/output resources. */
    if (g_ctx) { mpp_destroy(g_ctx); g_ctx = NULL; }
    if (frame) mpp_frame_deinit(&frame);
    if (packet) mpp_packet_deinit(&packet);
    if (packet_buffer) mpp_buffer_put(packet_buffer);
    enc_release();
    printf("TASK_PROBE_RC=%d enqueued=%d\n",rc,enqueued); fflush(stdout);
    return rc;
}
